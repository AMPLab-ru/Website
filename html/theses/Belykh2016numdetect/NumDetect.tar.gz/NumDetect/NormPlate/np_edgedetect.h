#ifndef EDGEDETECT_H
#define EDGEDETECT_H

#include <stdlib.h>
#include <stdio.h>

#include "nd_image.h"

enum np_error
{
	NP_INVALIDARG = 0x10,
	NP_ALLOCFAULT = 0x20,
	NP_FOPENERROR = 0x30
};

struct lineseg {
	int x0;
	int y0;
	int x1;
	int y1;
	int pointc;
};

int gaussblur(struct nd_image *img, double sigma);

int np_canny(struct nd_image *img, int *res, double thres1, double thres2);

int np_hough(int *img, int imgw, int imgh, double dang,
	double *lines, int linemaxc);

int np_houghseg(int *img, int imgw, int imgh, double *lines, int linec,
	struct lineseg *lineseg, int linesegc, double maxgap);

#endif
