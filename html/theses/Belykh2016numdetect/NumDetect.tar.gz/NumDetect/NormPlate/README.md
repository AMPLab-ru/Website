# NormPlate
Normalizing found number plate image
------

Usage:

	./normplate.sh [input image] [output image]
