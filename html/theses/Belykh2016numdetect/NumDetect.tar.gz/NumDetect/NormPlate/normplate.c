#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "nd_image.h"
#include "np_edgedetect.h"

#include <gtk/gtk.h>
#include <cairo.h>

int imghsplit(struct nd_image *img,
	struct nd_image *imgparts, int partc)
{

	double *outdata;
	int partn;

	if ((outdata = (double *) malloc(sizeof(double) * img->w * img->h))
		== NULL)
		exit(2);

	memcpy(outdata, img->data, sizeof(double) * img->w * img->h);

	for (partn = 0; partn < partc; ++partn) {
		imgparts[partn].w = img->w;
		imgparts[partn].h = img->h / partc;
		imgparts[partn].data
			= outdata + (img->w * (img->h * partn / partc));
	}

	return 0;
}

int imgvsplit(struct nd_image *img,
	struct nd_image *imgparts, int partc)
{
	double *outdata;
	int partw;
	int partn;

	partw = img->w / partc;

	if ((outdata = (double *) malloc(sizeof(double)
		* partw * img->h * partc)) == NULL)
		exit(2);

	for (partn = 0; partn < partc; ++partn) {
		int imgy;

		imgparts[partn].w = partw;
		imgparts[partn].h = img->h;
		imgparts[partn].data = outdata + partw * img->h * partn;

		for (imgy = 0; imgy < img->h; ++imgy)
			memcpy(imgparts[partn].data + imgy * partw,
				img->data + (imgy * img->w) + partw * partn,
				sizeof(double) * partw);
	}

	return 0;
}

double bandsum(struct nd_image *img, double rho0, double rho1, double theta)
{	
	int x, y;
	double s;	

	s = 0.0;

	for (y = 0; y < img->h; ++y)
		for (x = 0; x < img->w; ++x) {
			double pabs;
			double parg;
			double prho;

			parg = atan2((double) y, (double) x);
			pabs = sqrt(pow(x, 2.0) + pow(y, 2.0));

	
			prho = pabs * cos(parg - theta);
		
			if (prho > rho0 && prho < rho1)
				s += img->data[y * img->w + x];
		}

	return s;
}

double sign(double d)
{
	return d > 0.0 ? 1.0 : -1.0;
}

int checkline(struct nd_image *img, double rho, double theta,
	int lineorient)
{	
	if (lineorient < 2 && (theta > M_PI * 0.25 && theta < M_PI * 0.75))
		return 1;	

	if (lineorient >= 2
		&& !(theta > M_PI * 0.25 && theta < M_PI * 0.75)) {	
		double vbandlen = img->w * 0.125;
		double valdif;
		double sumborder;
		double suml;
		double sumr;

		suml = bandsum(img, rho - vbandlen * 1.5 - 0.01,
			rho - vbandlen * 0.5 + 0.01, theta);
		
		sumr = bandsum(img, rho + vbandlen * 0.5 - 0.01,
			rho + vbandlen * 1.5 + 0.01, theta);
		
		sumborder = bandsum(img, rho - vbandlen * 0.5 - 0.01,
			rho + vbandlen * 0.5 + 0.01, theta);

		valdif = ((lineorient == 2) ? sumr : suml) - sumborder;

		if (theta > M_PI / 2.0)
			valdif *= -1.0;

		return valdif > 0.0;
	}

	return 0;
}

int imgfindline(struct nd_image *img, struct lineseg *lseg,
	int lineorient, int hscale, char *imgpath)
{
	struct nd_image scaledimg;
	int *mask;
	double *lines;
	int linen;

	nd_imgnormalize(img, 1, 1);

	nd_imgscale(img, 1.0, hscale, &scaledimg);	

	if ((mask = (int *) malloc(sizeof(int) * scaledimg.w * scaledimg.h))
		== NULL)
		exit(2);

	np_canny(&scaledimg, mask, -1.0, -1.0);
	
	if ((lines = (double *) malloc(sizeof(double) * 100 * 2)) == NULL)
		exit(2);
	
	if (np_hough(mask, scaledimg.w, scaledimg.h, M_PI / 180.0, lines, 100))
		exit(2);

	for (linen = 0; linen < 25; ++linen) {
		double rho, theta;
	
		theta = lines[linen * 2 + 0];
		rho = lines[linen * 2 + 1];
		
		if (checkline(&scaledimg, rho, theta, lineorient)) {
			if (theta < 0.00001) {	
				lseg->x0 = rho;
				lseg->y0 = 0;

				lseg->x1 = rho;
				lseg->y1 = scaledimg.h;
			}
			else {		
				lseg->x0 = 0.0;
				lseg->y0 = rho / sin(theta);

				lseg->x1 = (double) scaledimg.w;
				lseg->y1 = (rho - (double) scaledimg.w
					* cos(theta)) / sin(theta);
			}

			break;
		}
	}

	free(mask);
	free(lines);

	return 0;
}

int lintersect(struct lineseg *l1, struct lineseg *l2,
	double *interx, double *intery)
{
	double m1, c1, m2, c2;
	double dx, dy;
	int isvert1, isvert2;

	isvert1 = isvert2 = 0;

	dx = l1->x1 - l1->x0;

	if (dx < 0.001)
		isvert1 = 1;
	else {
		dy = l1->y1 - l1->y0;
		m1 = dy / dx;
		c1 = l1->y0 - m1 * l1->x0;
	}

	dx = l2->x1 - l2->x0;

	if (dx < 0.001)
		isvert2 = 1;
	else {
		dy = l2->y1 - l2->y0;
		m2 = dy / dx;
		c2 = l2->y0 - m2 * l2->x0;
	}

	if (isvert1 || isvert2) {
		if (isvert1 && isvert2)
			return 0;
		if (isvert1 && !isvert2) {	
			*interx = (double) (l1->x0);
			*intery = (double) (l2->y0) + m2 * (double) (l1->x0);
		
			return 1;
		}

		if (isvert2 && !isvert1) {
			*interx = (double) (l2->x0);
			*intery = (double) (l1->y0) + m1 * (double) (l2->x0);
			
			return 1;
		}
	}
	else {	
		if( (m1 - m2) == 0)
			return 0;
		else {
			*interx = (c2 - c1) / (m1 - m2);
			*intery = m1 * *interx + c1;
		
			return 1;
		}
	}

	return 0;
}

int main(int argc, char **argv)
{
	struct nd_image img;

	struct nd_image *imgparts;
	
	struct lineseg lseg [4];

	double interx, intery;

// loading image
	if (argc < 2) {
		fprintf(stderr,
			"First and second arguments must be specified.\n");
		exit(2);
	}
	
	if (nd_imgread(&img, argv[1], 1)) {
		fprintf(stderr, "Cannot read image from file \"%s\".\n",
			argv[2]);

		exit(2);
	}

// split image into two parts by a horizontal axis
	if ((imgparts = (struct nd_image *)
		malloc(sizeof(struct nd_image) * 2)) == NULL)
		return NP_ALLOCFAULT;

	imghsplit(&img, imgparts, 2);
	
// find line in a top part
	imgfindline(imgparts + 0, lseg + 0, 0, 1, "houghtop.png");

// find line in a bottom part
	imgfindline(imgparts + 1, lseg + 1, 1, 1, "houghbot.png");

	lseg[1].y0 += img.h / 2;
	lseg[1].y1 += img.h / 2;

// split image into four parts by a vertical axis
	if ((imgparts = (struct nd_image *)
		malloc(sizeof(struct nd_image) * 5)) == NULL)
		exit(2);

	imgvsplit(&img, imgparts, 5);

// find line in a left part
	imgfindline(imgparts + 0, lseg + 2, 2, img.w / img.h,
		"houghleft.png");

	lseg[2].y0 /= (int) (img.w / img.h);
	lseg[2].y1 /= (int) (img.w / img.h);
	
// find line in a right part
	imgfindline(imgparts + 4, lseg + 3, 3, img.w / img.h,
		"houghright.png");

	lseg[3].x0 += img.w * 4 / 5;
	lseg[3].x1 += img.w * 4 / 5;

	lseg[3].y0 /= (int) (img.w / img.h);
	lseg[3].y1 /= (int) (img.w / img.h);

// draw image with detected lines to .png file
/*
	drawlined(img.data, 1.0, img.w, img.h,
		lseg[0].x0, lseg[0].y0, lseg[0].x1, lseg[0].y1);

	drawlined(img.data, 1.0, img.w, img.h,
		lseg[1].x0, lseg[1].y0, lseg[1].x1, lseg[1].y1);

	drawlined(img.data, 1.0, img.w, img.h,
		lseg[2].x0, lseg[2].y0, lseg[2].x1, lseg[2].y1);

	drawlined(img.data, 1.0, img.w, img.h,
		lseg[3].x0, lseg[3].y0, lseg[3].x1, lseg[3].y1);

	imgtofd("hough.png", img.data, img.w, img.h, 255.0);
*/
// print coordinates of intersection points

	lintersect(lseg + 1, lseg + 3, &interx, &intery);
	printf("%d %d\n", (int) ceil(interx), (int) ceil(intery));

	lintersect(lseg + 1, lseg + 2, &interx, &intery);
	printf("%d %d\n", (int) ceil(interx), (int) ceil(intery));

	lintersect(lseg + 0, lseg + 3, &interx, &intery);
	printf("%d %d\n", (int) ceil(interx), (int) ceil(intery));

	lintersect(lseg + 0, lseg + 2, &interx, &intery);
	printf("%d %d\n", (int) ceil(interx), (int) ceil(intery));

	return 0;
}
