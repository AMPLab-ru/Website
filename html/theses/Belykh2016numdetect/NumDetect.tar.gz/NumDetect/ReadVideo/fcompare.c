#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <string.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <png.h>

#include "iplimage.h"
#include "iplvideo.h"
#include "ipldefs.h"

#include "nd_image.h"

int ipltondimg(struct IplImage *iplimg, struct nd_image *ndimg, int hsvval)
{
	int x, y;

	ndimg->w = iplimg->width;
	ndimg->h = iplimg->height;
	ndimg->data = calloc(ndimg->w * ndimg->h, sizeof(double));

	for (y = 0; y < ndimg->h; ++y)
		for (x = 0; x < ndimg->w; ++x) {
			if (hsvval) {
				int c;
				double val;

				val = iplimg->data[(y * iplimg->width + x)
					* iplimg->nchans + 0];

				for (c = 1; c < iplimg->nchans; ++c) {
					double cval;

					cval = iplimg->data[(y * iplimg->width + x)
						* iplimg->nchans + c];

					val = (cval > val) ? cval : val;
				}

				ndimg->data[y * ndimg->w + x] = val / 255.0;
			}
		}

	return 0;
}


int main(int argc, char **argv)
{
	int flag;
	struct IplImage *frame;
	struct IplDev *dev;

	if ((dev = ipl_opendev(0, IPL_RGB_MODE)) == NULL) {
		printf("error while creating device 0\n");
		return 1;
	}

	if (ipl_setparams(dev, 320, 240, IPL_FORCE_SCALE_OFF) < 0) {
		fprintf(stderr, "error on changing cam params\n");
		free(dev);
		return 1;
	}

	flag = 1;
	
	int fn;

	fn = 0;
	while (flag) {
		struct nd_image ndframe;
		
		char a[255];

		sprintf(a, "%d.png", fn++);

		if ((frame = ipl_getframe(dev)) == NULL) {
			printf("error capturing curr1\n");
			return 1;
		}

		ipltondimg(frame, &ndframe, 1);

		nd_imgwrite(&ndframe, a);

		free(ndframe.data);
		ipl_freeimg(&frame);
	}


	return 0;
}
