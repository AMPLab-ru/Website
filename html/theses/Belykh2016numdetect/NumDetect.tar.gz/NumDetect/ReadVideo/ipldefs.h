#ifndef _H_IPLDEFS
#define _H_STLDEFS

#define IPL_GRAY_MODE 0
#define IPL_RGB_MODE 1

#endif
