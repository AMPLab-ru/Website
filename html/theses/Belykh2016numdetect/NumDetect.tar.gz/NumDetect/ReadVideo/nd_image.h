#ifndef ND_IMAGE_H
#define ND_IMAGE_H

enum nd_error
{
	ND_INVALIDARG = 0x10,
	ND_ALLOCFAULT = 0x20,
	ND_FOPENERROR = 0x30
};

struct nd_image {
	int w;
	int h;
	double *data;
};

int nd_imgread(struct nd_image *img, const char *imgpath, int hsvval);

int nd_imgwrite(const struct nd_image *img, const char *imgpath);

int nd_imgnormalize(struct nd_image *img, int avr, int dev);

int nd_imggetrect(const struct nd_image *imgin,
	struct nd_image *imgout, int x0, int y0);

int nd_imgscale(const struct nd_image *inimg, double wrel, double hrel,
	struct nd_image *outimg);

#endif
