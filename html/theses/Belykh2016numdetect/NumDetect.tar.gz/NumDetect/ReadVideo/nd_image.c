#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <cairo.h>

#include "nd_image.h"

struct rgb
{
	unsigned char b, g, r, a;
};

int nd_imgread(struct nd_image *img, const char *imgpath, int hsvval)
{
	cairo_surface_t *image;	
	struct rgb *idata;
	int w, h;
		
	int npix;
	
	if (img == NULL)
		return (ND_INVALIDARG | 0x00);

	image = cairo_image_surface_create_from_png(imgpath);

	if (cairo_surface_status(image) != CAIRO_STATUS_SUCCESS)
		return ND_FOPENERROR;
	
	idata = (struct rgb *) cairo_image_surface_get_data(image);
	w = cairo_image_surface_get_width(image);
	h = cairo_image_surface_get_height(image);	

	img->w = w;
	img->h = h;

	if ((img->data = (double *) malloc(sizeof(double *) * w * h)) == NULL)
		return ND_ALLOCFAULT;

	for (npix = 0; npix < w * h; ++npix)
		if (hsvval) {
			int maxc;

			maxc = idata[npix].r;
			maxc = (idata[npix].g > maxc) ? idata[npix].g : maxc;
			maxc = (idata[npix].b > maxc) ? idata[npix].b : maxc;

			img->data[npix] = (double) maxc / 255.0;
		}
		else {
			img->data[npix] = (double) (idata[npix].r
				+ idata[npix].g + idata[npix].b) / 3.0 / 255.0;
		}

	cairo_surface_destroy(image);
	
	return 0;
}

int nd_imgwrite(const struct nd_image *img, const char *imgpath)
{
	cairo_surface_t *image;	
	struct rgb *outdata;
	int imgy;
	int imgx;

	if (img == NULL)
		return (ND_INVALIDARG | 0x00);

	if (imgpath == NULL)
		return (ND_INVALIDARG | 0x01);

	image = cairo_image_surface_create(CAIRO_FORMAT_RGB24, img->w, img->h);	
	outdata = (struct rgb *) cairo_image_surface_get_data(image);
	
	for (imgy = 0; imgy < img->h; ++imgy)
		for (imgx = 0; imgx < img->w; ++imgx) {
			int val;
			
			val = ceil(img->data[imgy * img->w + imgx] * 255.0);
			
			outdata[imgy * img->w + imgx].r
			= outdata[imgy * img->w + imgx].g
			= outdata[imgy * img->w + imgx].b
			= (val <= 255) ? (val >= 0 ? val : 0) : 255;
		}

	if (cairo_surface_write_to_png(image, imgpath) != CAIRO_STATUS_SUCCESS)
		return ND_FOPENERROR;
	
	cairo_surface_destroy(image);

	return 0;
}

int nd_imgscale(const struct nd_image *inimg, double wrel, double hrel,
	struct nd_image *outimg)
{
	int x, y;

	if (inimg == NULL)
		return (ND_INVALIDARG | 0x00);

	if (hrel <= 0.0)
		return (ND_INVALIDARG | 0x01);

	if (wrel <= 0.0)
		return (ND_INVALIDARG | 0x02);
	
	if (outimg == NULL)
		return (ND_INVALIDARG | 0x03);

	outimg->w = ceil(wrel * inimg->w);	
	outimg->h = ceil(hrel * inimg->h);

	if ((outimg->data = (double *) malloc(sizeof(double)
		* outimg->w * outimg->h)) == NULL)
		return ND_ALLOCFAULT;
	
	for (y = 0; y < outimg->h; ++y)
		for (x = 0; x < outimg->w; ++x) {
			int inx0, iny0;
			int inx1, iny1;
			double iny, inx;
			double d00, d01, d10, d11;
			double sumd;

			iny = ((double) y) / hrel;
			inx = ((double) x) / wrel;

			iny0 = (int) iny;
			inx0 = (int) inx;

			iny1 = (int) iny + 1;
			inx1 = (int) inx + 1;

			d00 = sqrt(pow((double) iny0 - iny, 2.0) 
				+ pow((double) inx0 - inx, 2.0));

			d01 = sqrt(pow((double) iny0 - iny, 2.0) 
				+ pow((double) inx1 - inx, 2.0));

			d10 = sqrt(pow((double) iny1 - iny, 2.0) 
				+ pow((double) inx0 - inx, 2.0));

			d11 = sqrt(pow((double) iny1 - iny, 2.0) 
				+ pow((double) inx1 - inx, 2.0));


			if (iny0 < 0)
				d00 = d01 = 0.0;
			if (iny1 >= inimg->h)
				d10 = d11 = 0.0;
			if (inx0 < 0)
				d00 = d10 = 0.0;
			if (inx1 >= inimg->w)
				d01 = d11 = 0.0;

			sumd = d00 + d01 + d10 + d11;

			d00 = sumd - d00;
			d01 = sumd - d01;
			d10 = sumd - d10;
			d11 = sumd - d11;
			
			sumd = d00 + d01 + d10 + d11;

			d00 /= sumd;
			d01 /= sumd;
			d10 /= sumd;
			d11 /= sumd;

			double p00, p01, p10, p11;

			if ((iny0 >= 0 && iny0 < inimg->h)
				&& (inx0 >= 0 && inx0 < inimg->w))
				p00 = inimg->data[iny0 * inimg->w + inx0];
			else
				p00 = 0.0;

			if ((iny0 >= 0 && iny0 < inimg->h)
				&& (inx1 >= 0 && inx1 < inimg->w))
				p01 = inimg->data[iny0 * inimg->w + inx1];
			else
				p01 = 0.0;

			if ((iny1 >= 0 && iny1 < inimg->h)
				&& (inx0 >= 0 && inx0 < inimg->w))
				p10 = inimg->data[iny1 * inimg->w + inx0];
			else
				p10 = 0.0;

			if ((iny1 >= 0 && iny1 < inimg->h)
				&& (inx1 >= 0 && inx1 < inimg->w))
				p11 = inimg->data[iny1 * inimg->w + inx1];
			else
				p11 = 0.0;

			outimg->data[y * outimg->w + x]
				= d00 * p00 + d01 * p01
					+ d10 * p10 + d11 * p11; 			 			 
	}

	return 0;
}

int nd_imgnormalize(struct nd_image *img, int normavr, int normdev)
{
	double avr;
	double sd;
	int npix;

	if (img == NULL)
		return (ND_INVALIDARG | 0x00);

	avr = 0.0;
	for (npix = 0; npix < img->w * img->h; ++npix)
		avr += img->data[npix];
	avr /= (double) (img->w * img->h);

	sd = 0.0;	
	for (npix = 0; npix < img->w * img->h; ++npix)
		sd += pow(img->data[npix] - avr, 2.0);
	sd = sqrt(sd / (double) (img->w * img->h));

	if (normavr)
		for (npix = 0; npix < img->w * img->h; ++npix)
			img->data[npix] -= avr;
	
	if (normdev)
		for (npix = 0; npix < img->w * img->h; ++npix)
			img->data[npix] /= sd;
	
	return 0;
}

int nd_imggetrect(const struct nd_image *imgin,
	struct nd_image *imgout, int x0, int y0)
{
	int x;
	int y;

	if (imgin == NULL)
		return (ND_INVALIDARG | 0x00);

	if (imgout == NULL)
		return (ND_INVALIDARG | 0x01);

	if (x0 < 0)
		return (ND_INVALIDARG | 0x02);

	if (y0 < 0)
		return (ND_INVALIDARG | 0x03);

	for (y = 0; y < imgout->h; ++y)
		for (x = 0; x < imgout->w; ++x)
			imgout->data[y * imgout->w + x]
				= imgin->data[(y0 + y) * imgin->w + (x0 + x)];
	
	return 0;
}
