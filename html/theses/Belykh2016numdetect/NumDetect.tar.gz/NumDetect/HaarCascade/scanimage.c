#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <pthread.h>

#include <cairo.h>

#include "hc_hcascade.h"
#include "hc_rect.h"

int foundn = 1;

int imgscan(struct nd_image *img, struct hc_hcascade *hc,
	struct hc_rect **r, int *roffset, int *rmax)
{
	struct nd_image imginwin;
	int x;
	int y;

	imginwin.w = hc->ww;
	imginwin.h = hc->wh;
	if ((imginwin.data = (double *) malloc(sizeof(double)
		* hc->ww * hc->wh)) == NULL)
		exit(2);

	for (y = 0; y <= img->h - hc->wh; ++y)
		for (x = 0; x <= img->w - hc->ww; ++x) {
			if (nd_imggetrect(img, &imginwin, x, y))
				exit(2);

			if (nd_imgnormalize(&imginwin, 0, 1))
				exit(2);

			if (hc_imgintegral(&imginwin))
				exit(2);

			if (hc_imgclassify(hc, &imginwin)) {	
				if (*roffset >= *rmax) {
					*rmax = (*rmax > 0) ? (*rmax * 2) : 1;
	
					if ((*r = realloc(*r,
						sizeof(struct hc_rect)
						* *rmax)) == NULL)
						exit(2);
				}
			
				(*r)[*roffset].x0 = (double) x;
				(*r)[*roffset].y0 = (double) y;
				(*r)[*roffset].x1 = (double) (x + hc->ww);
				(*r)[*roffset].y1 = (double) (y + hc->wh);
	
				++(*roffset);
			}
		}

	return 0;
}

int main(int argc, char **argv)
{	
	struct hc_hcascade hc;
	int imgc;

	struct nd_image img;
	
	double d;
	
	struct hc_rect *r;
	int rmax;
	int rc;
	int rn;

	struct hc_rect *newr;
	int newrc;

	time_t t;

	if (hc_hcascaderead(&hc, NULL, &imgc, argv[1])) {
		fprintf(stderr, "Cannot read cascade data from file \"%s\".\n",
			argv[1]);
		exit(2);
	}
	
	if (nd_imgread(&img, argv[2], 0)) {
		fprintf(stderr, "Cannot read image from file \"%s\".\n",
			argv[2]);

		exit(2);
	}

	t = time(0);
	
	r = NULL;
	rc = 0;
	rmax = 0;

	d = 1.0;	
	do {
		struct nd_image scaledimg;
		int prevrc;

		if (nd_imgscale(&img, d, d, &scaledimg))
			exit(2);
	
		printf("scale = %f\n", d);
		if (scaledimg.w < hc.ww || scaledimg.h < hc.wh)
			break;
	
		prevrc = rc;
		imgscan(&scaledimg, &hc, &r, &rc, &rmax);	
	
		for (rn = prevrc; rn < rc; ++rn) {
			r[rn].x0 /= d;
			r[rn].y0 /= d;
			r[rn].x1 /= d;
			r[rn].y1 /= d;
		}

		d *= 0.9;
	} while (1);
	
	printf("%lu\n", time(0) - t);

	if (rc <= 0)
		exit(1);

	if (hc_conrect(r, rc, &newr, &newrc))
		exit(2);

	for (rn = 0; rn < newrc; ++rn) {
		char a[255];

		sprintf(a, "%s/%u.png", argv[3], rn);
		
		double rh = abs(newr[rn].y0 - newr[rn].y1);

		newr[rn].y0 = (int) (newr[rn].y0) - (rh * 0.15);
		newr[rn].y1 = newr[rn].y1 + (rh * 0.15);

		if (newr[rn].y0 >= 0 && newr[rn].y1 < img.h) {
			struct nd_image imginwin;

			imginwin.w = abs(newr[rn].x1 - newr[rn].x0);
			imginwin.h = abs(newr[rn].y1 - newr[rn].y0);
			imginwin.data = (double *) malloc(sizeof(double)
				* imginwin.w * imginwin.h);
	
			nd_imggetrect(&img, &imginwin,
				newr[rn].x0, newr[rn].y0);
			
			nd_imgwrite(&imginwin, a);
		}
	}

	return 0;
}
