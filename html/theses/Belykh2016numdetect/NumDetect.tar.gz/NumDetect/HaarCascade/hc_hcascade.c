#include "hc_hcascade.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <pthread.h>

struct hc_findwcthreadarg {
	struct hc_wclassifier *wc;
	uint wcc;
	struct nd_image *feature;
	struct nd_image *img;
	int *isgood;
	uint imgc;
	double *w;
};	

struct hc_findwcthreadret {
	struct hc_wclassifier minerrwc;
	int *iserror;
	double minwcerr;
};	

struct hprimvalue {
	double val;
	uint imgn;
};

int hc_create(struct hc_hcascade *hc, int ww, int wh, 
	const struct nd_image *feature, int featurec)
{
	if (hc == NULL)
		return (HC_INVALIDARG | 0x00);

	if (ww <= 0)
		return (HC_INVALIDARG | 0x01);

	if (wh <= 0)
		return (HC_INVALIDARG | 0x02);

	if (feature == NULL)
		return (HC_INVALIDARG | 0x03);

	if (featurec <= 0)
		return (HC_INVALIDARG | 0x04);

	hc->wh = wh;
	hc->ww = ww;

	if ((hc->feature = (struct nd_image *) malloc(sizeof(struct nd_image)
		* featurec)) == NULL)	
		return HC_ALLOCFAULT;

	memcpy(hc->feature, feature, sizeof(struct nd_image) * featurec);

	hc->featurec = featurec;

	hc->wc = NULL;
	hc->wccoef = NULL;
	hc->wccount = 0;
	hc->stagecount = 0;

	return 0;
}

int hc_hcascaderead(struct hc_hcascade *hc,
	double *weights, int *imgc, const char *hcpath)
{
	FILE *hcfile;
	int fn;
	int imgn;
	int stn;
	int wcn;
	
	if (hc == NULL)
		return (HC_INVALIDARG | 0x00);
	
	if (hcpath == NULL)
		return (HC_INVALIDARG | 0x03);

	if ((hcfile = fopen(hcpath, "r")) == NULL)
		return HC_FOPENERROR;

	fscanf(hcfile, "%d %d\n", &(hc->ww), &(hc->wh));

	fscanf(hcfile, "%d\n", &(hc->featurec));

	if ((hc->feature = (struct nd_image *) malloc(sizeof(struct nd_image)
		* hc->featurec)) == NULL)
		return HC_ALLOCFAULT;

	for (fn = 0; fn < hc->featurec; ++fn) {
		int pixn;
		int pixc;

		fscanf(hcfile, "%d %d ", &(hc->feature[fn].w),
			&(hc->feature[fn].h));

		pixc = hc->feature[fn].w * hc->feature[fn].h;

		if ((hc->feature[fn].data = (double *) malloc(sizeof(double)
			* pixc)) == NULL)
			return HC_ALLOCFAULT;

		for (pixn = 0; pixn < pixc; ++pixn)
			fscanf(hcfile, "%lf", hc->feature[fn].data + pixn);
	}


	fscanf(hcfile, "%u\n", &(hc->wccount));

	if (((hc->wc) = (struct hc_wclassifier *)
		malloc(sizeof(struct hc_wclassifier) * (hc->wccount))) == NULL)
		return HC_ALLOCFAULT;

	for (wcn = 0; wcn < hc->wccount; ++wcn) {
		fscanf(hcfile, "%d %u %u %u %u %lf %lf\n",
			&((hc->wc)[wcn].fn),
			&((hc->wc)[wcn].x),
			&((hc->wc)[wcn].y),
			&((hc->wc)[wcn].w),
			&((hc->wc)[wcn].h),
			&((hc->wc)[wcn].ineqdir),
			&((hc->wc)[wcn].thres));
	}

	if ((hc->wccoef = malloc(sizeof(double) * (hc->wccount))) == NULL)
		return HC_ALLOCFAULT;

	for (wcn = 0; wcn < (hc->wccount); ++wcn)
		fscanf(hcfile, "%lf", (hc->wccoef) + wcn);

	fscanf(hcfile, "%d\n", imgc);
	
	for (imgn = 0; imgn < *imgc; ++imgn) {
		double trash;

		fscanf(hcfile, "%lf", (weights != NULL)
			? (weights + imgn) : &trash);
	}

	fscanf(hcfile, "%u", &(hc->stagecount));
	
	if ((hc->stage = (struct hc_stage *) malloc(sizeof(struct hc_stage)
		* hc->stagecount)) == NULL)
		return HC_ALLOCFAULT;
	
	for (stn = 0; stn < hc->stagecount; ++stn)
		fscanf(hcfile, "%u %lf\n", &((hc->stage)[stn].wcc),
			&((hc->stage)[stn].thres));

	fclose(hcfile);

	return 0;
}

int hc_hcascadewrite(struct hc_hcascade *hc,
	double *weight, int imgc, const char *hcpath)
{
	FILE *outfile;
	int fn;
	int imgn;
	int wcn;
	int stn;

	if (hc == NULL)
		return (HC_INVALIDARG | 0x00);

	if (weight == NULL)
		return (HC_INVALIDARG | 0x01);
	
	if (imgc == 0)
		return (HC_INVALIDARG | 0x02);

	if (hcpath == NULL)
		return (HC_INVALIDARG | 0x03);


	if ((outfile = fopen(hcpath, "w")) == NULL)
		return HC_FOPENERROR;

	fprintf(outfile, "%d %d\n", hc->ww, hc->wh);

	fprintf(outfile, "%d\n", hc->featurec);

	for (fn = 0; fn < hc->featurec; ++fn) {
		int pixn;
		int pixc;

		fprintf(outfile, "%d %d ", hc->feature[fn].w,
			hc->feature[fn].h);

		pixc = hc->feature[fn].w * hc->feature[fn].h;

		for (pixn = 0; pixn < pixc; ++pixn)
			fprintf(outfile, "%lf%c", hc->feature[fn].data[pixn],
				(pixn != pixc - 1) ? ' ' : '\n');
	}

	fprintf(outfile, "%d\n", hc->wccount);

	for (wcn = 0; wcn < hc->wccount; ++wcn) {
		fprintf(outfile, "%d %d %d %d %d %lf %lf\n",
			hc->wc[wcn].fn,
			hc->wc[wcn].x,
			hc->wc[wcn].y,
			hc->wc[wcn].w,
			hc->wc[wcn].h,
			hc->wc[wcn].ineqdir,
			hc->wc[wcn].thres);
	}

	for (wcn = 0; wcn < hc->wccount; ++wcn) {
		fprintf(outfile, "%lf%c", hc->wccoef[wcn],
			(wcn != hc->wccount - 1) ? ' ' : '\n');
	}
	
	fprintf(outfile, "%d\n", imgc);

	for (imgn = 0; imgn < imgc; ++imgn)
		fprintf(outfile, "%lf%c", weight[imgn],
			(imgn != imgc - 1) ? ' ' : '\n');

	fprintf(outfile, "%d\n", hc->stagecount);
	
	for (stn = 0; stn < hc->stagecount; ++stn)
		fprintf(outfile, "%d %lf\n", hc->stage[stn].wcc,
			hc->stage[stn].thres);
		
	fclose(outfile);

	return 0;
}

static int hc_next_wclassifier(struct hc_wclassifier *wc,
	struct nd_image *feature, uint featurec, uint wh, uint ww)
{
	if (wc->fn == -1) {
		wc->fn = 0;

		wc->x = 0;
		wc->y = 0;

		wc->h = feature[wc->fn].h;
		wc->w = feature[wc->fn].w;
	}
	else if (wc->x + wc->w  < ww)
		++wc->x;
	else if (wc->y + wc->h < wh) {
		wc->x = 0;
		++wc->y;
	}
	else if (wc->h < wh) {
		wc->x = 0;
		wc->y = 0;
		
		++wc->h;
	}
	else if (wc->w < ww) {
		wc->h = feature[wc->fn].h;
	
		wc->x = 0;
		wc->y = 0;
	
		++wc->w;
	}
	else if (wc->fn + 1 < featurec) {
		++wc->fn;

		wc->x = 0;
		wc->y = 0;
	
		wc->h = feature[wc->fn].h;
		wc->w = feature[wc->fn].w;
	}
	else
		return 0;

	return 1;
}

inline double hc_gethprimval(const struct hc_wclassifier *wc,
	const struct nd_image *feat, const struct nd_image *img)
{
	int fx, fy;
	double s;
	double wrel;
	double hrel;
	uint ywoffset;
	double relfxoffset;
	double relfyoffset;
	
	wrel = (double) wc->w / (double) feat->w;
	hrel = (double) wc->h / (double) feat->h;

	s = 0.0;

	ywoffset = 0;
	relfyoffset = 0.0;

	for (fy = 0; fy < feat->h; ++fy) {	
		relfxoffset = 0.0;
		for (fx = 0; fx < feat->w; ++fx) {
			int imgx0;
			int imgy0;
			int imgx1;
			int imgy1;

			double sx1y0;
			double sx0y1;
			double sx0y0;;
			double sx1y1;

			imgx0 = (uint) (relfxoffset) + wc->x - 1;
			imgy0 = img->w
				* ((uint) (relfyoffset) + wc->y - 1);	

			imgx1 = (uint) (relfxoffset + wrel) + wc->x - 1;
			imgy1 = img->w
				* ((uint) (relfyoffset + hrel) + wc->y - 1);

			
			sx1y1 = img->data[imgy1 + imgx1];

			if (imgx0 >= 0 && imgy0 >= 0) {
				sx1y0 = img->data[imgy0 + imgx1];
				sx0y1 = img->data[imgy1 + imgx0];
				sx0y0 = img->data[imgy0 + imgx0];
			}
			else {	
				sx1y0 = (imgy0 >= 0)
					? img->data[imgy0 + imgx1]
					: 0.0;

				sx0y1 = (imgx0 >= 0)
					? img->data[imgy1 + imgx0]
					: 0.0;
			
				sx0y0 = 0.0;
			}

			s += feat->data[ywoffset + fx]
				* (sx1y1 - sx1y0 - sx0y1 + sx0y0);
		
			relfxoffset += wrel;
		}

		ywoffset += feat->w;
		relfyoffset += hrel;
	}
	
	return s;
}

static int hc_wclassify(const struct hc_wclassifier *wc,
	const struct nd_image *feat, const struct nd_image *img)
{
	return ((wc->ineqdir * hc_gethprimval(wc, feat, img))
		< (wc->ineqdir * wc->thres));
}

int hc_imgintegral(struct nd_image *img)
{
	uint x;
	uint y;
	double *imginteg;

	if ((imginteg = (double *) malloc(sizeof(double) * img->h * img->w))
		== NULL)
		return (HC_INVALIDARG | 0x00);

	for (y = 0; y < img->h; ++y)
		for (x = 0; x < img->w; ++x)
			imginteg[y * img->w + x] = 0.0;


	imginteg[0] = img->data[0];

	for (x = 1; x < img->w; ++x)
		imginteg[x] = img->data[x] + imginteg[(x - 1)];

	for (y = 1; y < img->h; ++y)
		imginteg[y * img->w] = img->data[y * img->w]
			+ imginteg[(y -1) * img->w];

	for (y = 1; y < img->h; ++y)
		for (x = 1; x < img->w; ++x) {
			imginteg[y * img->w + x]
				= imginteg[(y -1) * img->w + x]
				+ imginteg[y * img->w + (x - 1)]
				- imginteg[(y - 1) * img->w + (x - 1)]
				+ img->data[y * img->w + x];
		}

	free(img->data);
	img->data = imginteg;

	return 0;
}

static int hc_initweights(double *w, struct nd_image *img,
	int *isgood, uint imgc)
{
	uint imgn;
	uint goodec;
	uint badec;

	goodec = badec = 0;	
	for (imgn = 0; imgn < imgc; ++imgn)
		if (isgood[imgn])
			++goodec;
		else
			++badec;

	for (imgn = 0; imgn < imgc; ++imgn)
		w[imgn] = 1.0
			/ (2.0 * (double) (isgood[imgn] ? goodec : badec));
	
	return 0;
}

static int comphval(const void *hv0, const void *hv1)
{
	return ((((struct hprimvalue *) hv0)->val
		> ((struct hprimvalue *) hv1)->val) ? 1 : -1);

}

static double hc_trainwclassifier(struct hc_wclassifier *curwc,
	struct nd_image *feature, struct nd_image *img, int *isgood, uint imgc,
	double *w)
{
	uint imgn;
	struct hprimvalue *hpval;
	double minerr;
	double minerrthres;
	double minerrdir;
	double thres;

	uint curimgn;
	double *goodwi;
	double *badwi;

	hpval = (struct hprimvalue *) malloc(sizeof(struct hprimvalue) * imgc);
	
	goodwi = (double *) malloc(sizeof(double) * imgc);
	badwi = (double *) malloc(sizeof(double) * imgc);

	for (imgn = 0; imgn < imgc; ++imgn) {
		hpval[imgn].val = hc_gethprimval(curwc,
			feature + curwc->fn, img + imgn);
		hpval[imgn].imgn = imgn;
	}

	qsort(hpval, imgc, sizeof(struct hprimvalue), comphval);

	curimgn = hpval[0].imgn;
	
	goodwi[0] = (isgood[curimgn]) ? w[curimgn] : 0.0;
	badwi[0] = (isgood[curimgn]) ? 0.0 : w[curimgn];

	for (imgn = 1; imgn < imgc; ++imgn) {
		curimgn = hpval[imgn].imgn;

		goodwi[imgn] = goodwi[imgn - 1]
			+ ((isgood[curimgn]) ? w[curimgn] : 0.0);
		badwi[imgn] = badwi[imgn - 1]
			+ ((isgood[curimgn]) ? 0.0 : w[curimgn]);
	}


	minerr = 1.0;
	minerrthres = 0.0;
	minerrdir = 1.0;

	for (imgn = 1; imgn < imgc; ++imgn) {
		double err;

		thres = (hpval[imgn - 1].val + hpval[imgn].val) * 0.5;

		err = badwi[imgn - 1] + goodwi[imgc - 1] - goodwi[imgn - 1];

		if (err < minerr) {
			minerr = err;
			minerrthres = thres;
			minerrdir = 1.0;
		}

		err = goodwi[imgn - 1] + badwi[imgc - 1] - badwi[imgn - 1];

		if (err < minerr) {
			minerr = err;
			minerrthres = thres;
			minerrdir = -1.0;
		}
	}

	free(goodwi);
	free(badwi);
	free(hpval);

	curwc->thres = minerrthres;
	curwc->ineqdir = minerrdir;

	return minerr;
}


static void *findwcthreadfunc(void *a)
{
	uint wcn;
	double minwcerr;
	struct hc_wclassifier *minerrwc;
	struct hc_findwcthreadarg *arg;
	struct hc_findwcthreadret *ret;
	
	arg = (struct hc_findwcthreadarg *) a;

	minwcerr = 1.0;
	minerrwc = NULL;
	for (wcn = 0; wcn < arg->wcc; ++wcn) {
		double wcerror;

		wcerror = hc_trainwclassifier(arg->wc + wcn, arg->feature,
			arg->img, arg->isgood, arg->imgc, arg->w);
		
		if ((wcerror < minwcerr) || (wcn == 0)) {
			minwcerr = wcerror;
			minerrwc = arg->wc + wcn;
		}
	}

	ret = (struct hc_findwcthreadret *)
		malloc(sizeof(struct hc_findwcthreadret));

	ret->minerrwc = *minerrwc;
	ret->minwcerr = minwcerr;

	pthread_exit(ret);
}


static int hc_findbestwc(struct nd_image *feature, uint featurec, uint wh,
	uint ww, struct nd_image *img, int *isgood, uint imgc, double *weight,
	struct hc_wclassifier *minerrwc, double *minwcerr, uint threadwcc,
	uint tc)
{

	struct hc_wclassifier curwc;
	int islastpart;
	struct hc_wclassifier *wc;
	pthread_t *thrs;
	struct hc_findwcthreadarg *threadarg;
	struct hc_findwcthreadret **threadret;	

	if ((wc = (struct hc_wclassifier *) malloc(sizeof(struct hc_wclassifier)
		* threadwcc * tc)) == NULL)
		return HC_ALLOCFAULT;
	
	if ((thrs = (pthread_t *) malloc(sizeof(pthread_t) * tc)) == NULL)
		return HC_ALLOCFAULT;
	
	if ((threadarg = (struct hc_findwcthreadarg *)
		malloc(sizeof(struct hc_findwcthreadarg) * tc)) == NULL)
		return HC_ALLOCFAULT;

	if ((threadret = (struct hc_findwcthreadret **)
		malloc(sizeof(struct hc_findwcthreadret *) * tc)) == NULL)
		return HC_ALLOCFAULT;

	curwc.fn = -1;
	curwc.w = 0;
	curwc.h = 0;
	curwc.x = 0;
	curwc.y = 0;
	curwc.ineqdir = 1.0;
	curwc.thres = 0.0;

	*minwcerr = 1.0;
	*minerrwc = curwc;

	islastpart = 0;

	while(!islastpart) {
		uint tn;
		uint wcn;
		uint partwcc;
	
		partwcc = 0;
		for (wcn = 0; wcn < (threadwcc * tc); ++wcn) {
			int res;
			
			if ((res = hc_next_wclassifier(&curwc, feature,
				featurec, wh, ww)) == 0) {
				islastpart = 1;
				break;
			}

			++partwcc;
		
			wc[wcn] = curwc;
		}

		threadwcc = partwcc / tc;

		for (tn = 0; tn < tc; ++tn) {	
			threadarg[tn].wc = wc + tn * threadwcc;
			threadarg[tn].wcc = (tn != (tc - 1))
				? threadwcc : (partwcc - tn * threadwcc);
			threadarg[tn].feature = feature;
			threadarg[tn].img = img;
			threadarg[tn].isgood = isgood;
			threadarg[tn].imgc = imgc;
			threadarg[tn].w = weight;
	
			pthread_create(thrs + tn, NULL, &findwcthreadfunc,
				(void *)(threadarg + tn));
		}
	
		for (tn = 0; tn < tc; ++tn)
			pthread_join(thrs[tn], (void **) (threadret + tn));

		for (tn = 0; tn < tc; ++tn)
			if (threadret[tn]->minwcerr < *minwcerr) {
				*minwcerr = threadret[tn]->minwcerr;
				*minerrwc = threadret[tn]->minerrwc;
			}

		for (tn = 0; tn < tc; ++tn) {
			free(threadret[tn]);
		}
	}

	free(wc);
	free(thrs);
	free(threadarg);
	free(threadret);

	return 0;
}

int hc_findwc(struct hc_hcascade *hc, double **weights,
	struct nd_image *img, int *isgood, int imgc, int iterc)
{
	double *w;
	int wn;
	int imgn;
	int i;
	int *iserror;
	int res;

	if (hc == NULL)
		return (HC_INVALIDARG | 0x00);
	
	if (weights == NULL)
		return (HC_INVALIDARG | 0x01);

	if (img == NULL)
		return (HC_INVALIDARG | 0x02);

	if (isgood == NULL)
		return (HC_INVALIDARG | 0x03);

	if (imgc == 0)
		return (HC_INVALIDARG | 0x04);

	if (iterc == 0)
		return (HC_INVALIDARG | 0x05);

	for (imgn = 0; imgn < imgc; ++imgn) {
		if ((res = nd_imgnormalize(img + imgn, 0, 1)))
			return res;

		if ((hc_imgintegral(img + imgn)))
			return res;
	}

	if ((iserror = (int *) malloc(sizeof(int) * imgc)) == NULL)
		return HC_ALLOCFAULT;

	if (*weights == NULL) {
		if ((w = (double *) malloc(sizeof(double) * imgc)) == NULL)
			return HC_ALLOCFAULT;
	
		hc_initweights(w, img, isgood, imgc);
	}
	else
		w = *weights;
	
	for (i = 0; i < iterc; ++i) {
		double sumw;
		double minwcerr;
		struct hc_wclassifier minerrwc;
		ulong j;

		sumw = 0;
		for (wn = 0; wn < imgc; ++wn)
			sumw += w[wn];

		for (wn = 0; wn < imgc; ++wn)
			w[wn] /= sumw;

		if ((res = hc_findbestwc(hc->feature, hc->featurec,
			hc->wh, hc->ww, img, isgood, imgc, w,
			&minerrwc, &minwcerr, 500, 8)))
			return res;

		for (imgn = 0; imgn < imgc; ++imgn) {
			iserror[imgn] = abs(isgood[imgn]
				- hc_wclassify(&minerrwc, 
					hc->feature + minerrwc.fn, img + imgn));
		}

		double beta = minwcerr / (1.0 - minwcerr);

		for (j = 0; j < imgc; ++j)
			w[j] *= pow(beta, 1 - iserror[j]);

	
		++hc->wccount;

		if ((hc->wc = realloc(hc->wc, sizeof(struct hc_wclassifier)
			* hc->wccount)) == NULL)
			return HC_ALLOCFAULT;

		if ((hc->wccoef = realloc(hc->wccoef, sizeof(double)
			* hc->wccount)) == NULL)
			return HC_ALLOCFAULT;

		hc->wc[hc->wccount - 1] = minerrwc;
		hc->wccoef[hc->wccount - 1] = log(1.0 / beta);
	}

	*weights = w;

	return 0;
}

static int hc_stageclassify(const struct hc_wclassifier *wc, const double *wccoef,
	const struct hc_stage *stage, const struct nd_image *feature,
	const struct nd_image *img)
{
	uint wcn;
	double res;

	res = 0.0;
	for (wcn = 0; wcn < stage->wcc; ++wcn)
		if (hc_wclassify(wc + wcn, feature + wc[wcn].fn, img))
			res += wccoef[wcn];

	return ((res >= stage->thres) ? 1 : 0);
}

static int hc_imgtest(const struct hc_wclassifier *wc,
	const double *wccoef, const struct hc_stage *stage, int stagec,
	const struct nd_image *feature, const struct nd_image *img)
{
	uint sn;

	int res = 1;

	for (sn = 0; sn < stagec; ++sn) {
		if (hc_stageclassify(wc, wccoef, stage + sn, 
			feature, img) == 0) {
			res = 0;
			break;
		}
	}

	return res;
}

const double hc_stagefprate(struct hc_wclassifier *wc, double *wccoef,
	struct hc_stage *stage, uint curstage, struct nd_image *img,
	int *isgood, int imgc, struct nd_image *feature, int *fpcount)
{
	uint fncount;
	uint imgn;
	uint laststimgc;


	fncount = 0;
	(*fpcount) = 0;
	laststimgc = 0;

	for (imgn = 0; imgn < imgc; ++imgn) {
		int res;
	
		res = hc_imgtest(wc, wccoef, stage, curstage,
			feature, img + imgn);

		if (res) {
			res = hc_stageclassify(wc, wccoef,
				stage + curstage, feature, img + imgn);

			if (isgood[imgn] == 0)
				++laststimgc;

			res = isgood[imgn] - res;
			
			if (res > 0)
				++fncount;
			if (res < 0)
				++(*fpcount);
		}
	}

	return (double) (*fpcount) / (double) laststimgc;
}

int hc_buildcascade(struct hc_hcascade *hc, struct nd_image *img, int *isgood,
	int imgc, double fprtarget)
{
	int imgn;
	int stagemaxc;
	int fpcount;
	int wcn;
	double *hvsum;
	int res;

	if (hc == NULL)
		return (HC_INVALIDARG | 0x00);

	if (img == NULL)
		return (HC_INVALIDARG | 0x01);

	if (isgood == NULL)
		return (HC_INVALIDARG | 0x02);

	if (imgc == 0)
		return (HC_INVALIDARG | 0x03);

	if (fprtarget < 0.0 || fprtarget > 1.0)
		return (HC_INVALIDARG | 0x04);
	
	stagemaxc = 1;
	hc->stagecount = 0;

	if ((hc->stage = (struct hc_stage *) malloc(sizeof(struct hc_stage)
		* stagemaxc)) == NULL)
		return HC_ALLOCFAULT;

	if ((hvsum = (double *) malloc(sizeof(double) * imgc)) == NULL)
		return HC_ALLOCFAULT;

	for (imgn = 0; imgn < imgc; ++imgn)
		hvsum[imgn] = 0.0;

	for (imgn = 0; imgn < imgc; ++imgn) {
		if ((res = nd_imgnormalize(img + imgn, 0, 1)))
			return res;

		if ((hc_imgintegral(img + imgn)))
			return res;
	}
	
	hc->stagecount = 0;
	hc->stage[hc->stagecount].wcc = 0;
	do {	
		double fprate;
		uint wcc;
		double minhvsum;
	
		wcc = hc->stage[hc->stagecount].wcc;
		
		for (imgn = 0; imgn < imgc; ++imgn)
			if (hc_wclassify(hc->wc + wcc,
				hc->feature + hc->wc[wcc].fn, img + imgn))
				hvsum[imgn] += hc->wccoef[wcc];
		
		minhvsum = hvsum[0];

		for (imgn = 1; imgn < imgc; ++imgn)
			if (isgood[imgn])
				minhvsum = (hvsum[imgn] < minhvsum)
					? hvsum[imgn] : minhvsum;
	
		hc->stage[hc->stagecount].thres	= minhvsum - 0.00001;

		fprate = hc_stagefprate(hc->wc, hc->wccoef, hc->stage,
			hc->stagecount, img, isgood, imgc, hc->feature,
			&fpcount);

		if (fprate > fprtarget)
			++(hc->stage[hc->stagecount].wcc);	
		else {
			++hc->stagecount;

			printf("\t%u %lf\n", wcc, fprate);
			
			if (hc->stagecount >= stagemaxc) {
				stagemaxc *= 2;

				if ((hc->stage = (struct hc_stage *)
					realloc(hc->stage,
					sizeof(struct hc_stage)
					* stagemaxc)) == NULL)
					return HC_ALLOCFAULT;
			}

			hc->stage[hc->stagecount].wcc
				= hc->stage[hc->stagecount - 1].wcc + 1;
		}

		if (fpcount == 0)
			break;

		if (hc->stage[hc->stagecount].wcc >= hc->wccount) {
			++hc->stagecount;
			break;			
		}

	} while (1);

	if (hc->stage[hc->stagecount - 1].wcc < hc->wccount) {	
		++hc->stagecount;
		
		if (hc->stagecount >= stagemaxc) {
			stagemaxc *= 2;

			if ((hc->stage = (struct hc_stage *) realloc(hc->stage,
				sizeof(struct hc_stage) * stagemaxc)) == NULL)
				return HC_ALLOCFAULT;
		}

		hc->stage[hc->stagecount - 1].wcc = hc->wccount;	
	}
	
	hc->stage[hc->stagecount - 1].thres = 0.0;

	for (wcn = 0; wcn < hc->stage[hc->stagecount - 1].wcc; ++wcn)
		hc->stage[hc->stagecount - 1].thres += hc->wccoef[wcn];

	hc->stage[hc->stagecount - 1].thres *= 0.5;

	return 0;
}

int hc_imgclassify(const struct hc_hcascade *hc, const struct nd_image *img)
{
	int sn;
	int res;

	res = 1;
	for (sn = 0; sn < hc->stagecount; ++sn)
		if (hc_stageclassify(hc->wc, hc->wccoef, hc->stage + sn, 
			hc->feature, img) == 0) {
			res = 0;
			break;
		}

	return res;
}
