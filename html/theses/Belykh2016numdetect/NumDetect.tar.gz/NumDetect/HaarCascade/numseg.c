#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <pthread.h>

#include <cairo.h>

#include "hc_hcascade.h"
#include "hc_rect.h"

int foundn = 1;

int imgscan(struct nd_image *img, struct hc_hcascade *hc,
	struct hc_rect **r, int *roffset, int *rmax)
{
	struct nd_image imginwin;
	int x;
	int y;

	imginwin.w = hc->ww;
	imginwin.h = hc->wh;
	if ((imginwin.data = (double *) malloc(sizeof(double)
		* hc->ww * hc->wh)) == NULL)
		exit(2);

	for (y = 0; y <= img->h - hc->wh; ++y)
		for (x = 0; x <= img->w - hc->ww; ++x) {
			if (nd_imggetrect(img, &imginwin, x, y))
				exit(2);

			if (nd_imgnormalize(&imginwin, 0, 1))
				exit(2);

			if (hc_imgintegral(&imginwin))
				exit(2);

			if (hc_imgclassify(hc, &imginwin)) {	
				if (*roffset >= *rmax) {
					*rmax = (*rmax > 0) ? (*rmax * 2) : 1;
	
					if ((*r = realloc(*r,
						sizeof(struct hc_rect)
						* *rmax)) == NULL)
						exit(2);
				}
			
				(*r)[*roffset].x0 = (double) x;
				(*r)[*roffset].y0 = (double) y;
				(*r)[*roffset].x1 = (double) (x + hc->ww);
				(*r)[*roffset].y1 = (double) (y + hc->wh);
	
				++(*roffset);
			}
		}

	return 0;
}

int connectres(struct hc_rect *r, int rc, struct hc_rect *newr)
{
	int rn;
	int newrc;

	struct hc_rect rsum;
	int rcount;

	newrc = 0;
	newr[newrc] = r[0];

	rsum.x0 = r[0].x0;
	rsum.y0 = r[0].y0;
	rsum.x1 = r[0].x1;
	rsum.y1 = r[0].y1;
		
	rcount = 1;
	
	for (rn = 1; rn < rc; ++rn) {
		if (abs(r[rn].x0 - r[rn - 1].x0) > 1) {	
			newr[newrc].x0 = rsum.x0 / rcount;
			newr[newrc].y0 = rsum.y0 / rcount;
			newr[newrc].x1 = rsum.x1 / rcount;
			newr[newrc].y1 = rsum.y1 / rcount;
		
			++newrc;
			
			newr[newrc] = r[rn];
	
			rsum.x0 = r[rn].x0;
			rsum.y0 = r[rn].y0;
			rsum.x1 = r[rn].x1;
			rsum.y1 = r[rn].y1;
			rcount = 1;		
		}
		else {
			rsum.x0 += r[rn].x0;
			rsum.y0 += r[rn].y0;
			rsum.x1 += r[rn].x1;
			rsum.y1 += r[rn].y1;
			++rcount;
		}
	}

	return newrc + 1;
}

int main(int argc, char **argv)
{	
	struct hc_hcascade hc;
	int imgc;

	struct nd_image img;
	
	struct hc_rect *r;
	int rmax;
	int rc;
	struct hc_rect *newr;
	uint newrc;
	int rn;

	if (hc_hcascaderead(&hc, NULL, &imgc, argv[1])) {
		fprintf(stderr, "Cannot read cascade data from file \"%s\".\n",
			argv[1]);
		exit(2);
	}
	
	if (nd_imgread(&img, argv[2], 0)) {
		fprintf(stderr, "Cannot read image from file \"%s\".\n",
			argv[2]);

		exit(2);
	}
	
	r = NULL;
	rc = 0;
	rmax = 0;	

	imgscan(&img, &hc, &r, &rc, &rmax);	

	if (rc <= 0)
		exit(1);

	if ((newr = (struct hc_rect *) malloc(sizeof(struct hc_rect) * rc))
		== NULL)
		exit(2);
/*
	for (rn = 0; rn < rc; ++rn) {
		struct nd_image imginwin;
		char a[255];

		sprintf(a, "%s/%u.png", argv[3], rn);

		imginwin.w = abs(r[rn].x1 - r[rn].x0);
		imginwin.h = abs(r[rn].y1 - r[rn].y0);
		if ((imginwin.data = (double *) malloc(sizeof(double)
			* imginwin.w * imginwin.h)) == NULL)
			exit(2);

		if (nd_imggetrect(&img, &imginwin, r[rn].x0, r[rn].y0))
			exit(2);
			
		if (nd_imgwrite(&imginwin, a)) {
			fprintf(stderr, "Cannot write data to file \"%s\".\n",
				argv[2]);
			
			exit(2);
		}
	}
*/
	
	newrc = connectres(r, rc, newr);
	
	if (newrc < 7)
		exit(1);

	for (rn = 0; rn < newrc; ++rn) {
		struct nd_image imginwin;
		char a[255];

		sprintf(a, "%s/%u.png", argv[3], rn);

		imginwin.w = abs(newr[rn].x1 - newr[rn].x0);
		imginwin.h = abs(newr[rn].y1 - newr[rn].y0);
		if ((imginwin.data = (double *) malloc(sizeof(double)
			* imginwin.w * imginwin.h)) == NULL)
			exit(2);

		if (nd_imggetrect(&img, &imginwin, newr[rn].x0, newr[rn].y0))
			exit(2);
			
		if (nd_imgwrite(&imginwin, a)) {
			fprintf(stderr, "Cannot write data to file \"%s\".\n",
				argv[2]);
			
			exit(2);
		}
	}


	return 0;
}
