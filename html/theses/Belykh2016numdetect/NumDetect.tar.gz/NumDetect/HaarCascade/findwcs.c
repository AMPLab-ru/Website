#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <cairo.h>

#include "hc_hcascade.h"

int imgtohfeature(struct nd_image *img)
{
	int pixn;
	
	for (pixn = 0; pixn < img->w * img->h; ++pixn) {
		img->data[pixn] *= 2.0;
		img->data[pixn] -= 1.0;
	}
	
	return 0;
}

int loadexlist(const char *exlistpath, int *winw, int *winh,
	struct nd_image **hfeature, int *hfeaturec,
	struct nd_image **img, int **isgood, int *imgc)
{	
	FILE *exlistfile;
	uint pn;
			
	exlistfile = fopen(exlistpath, "r");

	fscanf(exlistfile, "%d %d\n", winw, winh);

	fscanf(exlistfile, "%d\n", hfeaturec);
		
	(*hfeature) = (struct nd_image *) malloc(sizeof(struct nd_image)
		* *hfeaturec);
	
	for (pn = 0; pn < *hfeaturec; ++pn) {
		size_t len;
		ssize_t readc;
		char *hfeaturepath;

		hfeaturepath = NULL;
		len = 0;
		readc = getline(&hfeaturepath, &len, exlistfile);
		hfeaturepath[readc - 1] = '\0';

		nd_imgread(*hfeature + pn, hfeaturepath, 0);
		imgtohfeature(*hfeature + pn);
	}

	fscanf(exlistfile, "%d\n", imgc);
		
	(*img) = (struct nd_image *)
		malloc(sizeof(struct nd_image) * *imgc);
	(*isgood) = (int *) malloc(sizeof(int) * *imgc);

	
	for (pn = 0; pn < *imgc; ++pn) {
		size_t len;
		ssize_t readc;
		char *tmps;
			
		char *imgpath;
		
		tmps = NULL;
		len = 0;
		readc = getline(&tmps, &len, exlistfile);
	
		if (tmps[readc - 1] == '\n')
			tmps[readc - 1] = '\0';

		imgpath = strtok(tmps, " \t");

		nd_imgread(*img + pn, imgpath, 0);

		(*isgood)[pn] = atoi(strtok(NULL, " \t"));
	}
	
	fclose(exlistfile);

	return 0;
}

int main(int argc, const char **argv)
{
	struct hc_hcascade hcascade;
	
	int winw, winh;

	struct nd_image *hfeature;
	int hfeaturec;
	
	struct nd_image *img;
	int *isgood;
	int imgc;
		
	double *weights;

	int iterc;

	int wcn;

	if (argc < 3) {
		fprintf(stderr, "Not enough arguments\n");
		exit(1);
	}

	loadexlist(argv[1], &winw, &winh, &hfeature, &hfeaturec,
		&img, &isgood, &imgc);
	
	iterc = atoi(argv[2]);
	
	hc_create(&hcascade, winw, winh, hfeature, hfeaturec);

	if (argc > 4) {
		weights = (double *) malloc(sizeof(double) * imgc);
		hc_hcascaderead(&hcascade, weights, &imgc, argv[4]);
	}
	else
		weights = NULL;
	
	time_t t = time(0);
	hc_findwc(&hcascade, &weights, img, isgood, imgc, iterc);
	printf("%lu\n", time(0) - t);

	
	hcascade.stage = (struct hc_stage *) malloc(sizeof(struct hc_stage));
	hcascade.stagecount = 1;

	hcascade.stage[0].wcc = hcascade.wccount;
	
	hcascade.stage[0].thres = 0.0;

	for (wcn = 0; wcn < hcascade.wccount; ++wcn)
		hcascade.stage[0].thres += hcascade.wccoef[wcn];

	hcascade.stage[0].thres *= 0.5;
	
	hc_hcascadewrite(&hcascade, weights, imgc, argv[3]);	

	return 0;
}
