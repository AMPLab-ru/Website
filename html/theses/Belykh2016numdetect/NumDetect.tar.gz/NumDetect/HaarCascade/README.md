# HaarCascade
Haar cascade:
------

Finding weak classifiers:

	./makefindwcel.sh [examples width] [examples hegiht] [features directory] [good examples directory] [bad examples directory]
	./findwcs [wcs count] [examples list] [output file] [file with wcs from previous session]

Building cascade:

	./makebuildhcel.sh [examples width] [examples hegiht] [features directory] [examples directory]
	./buildcascade [examples list] [found weak classifiers list] [output file]

Scaning image with Haar cascade:

	./scanimage [cascade data] [input image] [output directory]

Finding symbols on normalized number plate:

	./numseg [cascade data] [input image] [output directory]

