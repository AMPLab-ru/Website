#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <cairo.h>

#include "hc_hcascade.h"

int imgtohfeature(struct nd_image *img)
{
	int pixn;
	
	for (pixn = 0; pixn < img->w * img->h; ++pixn) {
		img->data[pixn] *= 2.0;
		img->data[pixn] -= 1.0;
	}
	
	return 0;
}

int loadexlist(const char *exlistpath, struct nd_image **img,
	int **isgood, int *imgc)
{	
	FILE *exlistfile;
	uint pn;
			
	exlistfile = fopen(exlistpath, "r");

	fscanf(exlistfile, "%d\n", imgc);
		
	(*img) = (struct nd_image *)
		malloc(sizeof(struct nd_image) * *imgc);
	(*isgood) = (int *) malloc(sizeof(int) * *imgc);

	
	for (pn = 0; pn < *imgc; ++pn) {
		size_t len;
		ssize_t readc;
		char *tmps;
			
		char *imgpath;
		
		tmps = NULL;
		len = 0;
		readc = getline(&tmps, &len, exlistfile);
	
		if (tmps[readc - 1] == '\n')
			tmps[readc - 1] = '\0';

		imgpath = strtok(tmps, " \t");

		nd_imgread(*img + pn, imgpath, 0);

		(*isgood)[pn] = atoi(strtok(NULL, " \t"));
	}
	
	fclose(exlistfile);

	return 0;
}



int main(int argc, const char **argv)
{
	struct hc_hcascade hcascade;
	
	struct nd_image *img;	
	int *isgood;
	int previmgc;
	int imgc;
		
	loadexlist(argv[1], &img, &isgood, &imgc);

	hc_hcascaderead(&hcascade, NULL, &previmgc, argv[2]);
	
	hc_buildcascade(&hcascade, img, isgood, imgc, 0.5);
	
	hc_hcascadewrite(&hcascade, NULL, imgc, argv[3]);

	return 0;
}
