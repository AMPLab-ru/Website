#!/bin/bash

echo "$1 $2"

ls -f "$3" | grep .png | wc -l
ls "$3"/*.png

echo $(($(ls -f "$4" | grep .png | wc -l)
	+ $(ls -f "$5" | grep .png | wc -l)))

./printpaths.sh "$4" 1
./printpaths.sh "$5" 0
