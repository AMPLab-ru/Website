#ifndef HCASCADE_H
#define HCASCADE_H

#include <stdlib.h>

#include "nd_image.h"

enum hc_error
{
	HC_INVALIDARG = 0x10,
	HC_ALLOCFAULT = 0x20,
	HC_FOPENERROR = 0x30
};

struct hc_wclassifier
{
	int fn;
	uint h;
	uint w;
	uint x;
	uint y;

	double ineqdir;
	double thres;
};

struct hc_stage {
	uint wcc;
	double thres;
};

struct hc_hcascade {
	int wh;
	int ww;
		
	struct nd_image *feature;
	int featurec;

	struct hc_wclassifier *wc;
	double *wccoef;
	int wccount;

	struct hc_stage *stage;
	int stagecount;
};

int hc_create(struct hc_hcascade *hc, int wh, int ww,
	const struct nd_image *feature, int featurec);

int hc_hcascaderead(struct hc_hcascade *hc,
	double *weights, int *imgc, const char *hcpath);

int hc_hcascadewrite(struct hc_hcascade *hc,
	double *weight, int imgc, const char *hcpath);

int hc_imgintegral(struct nd_image *img);

int hc_findwc(struct hc_hcascade *hc, double **weights,
	struct nd_image *img, int *isgood, int imgc, int iterc);

int hc_buildcascade(struct hc_hcascade *hc, struct nd_image *img, int *isgood,
	int imgc, double fprtarget);

int hc_imgclassify(const struct hc_hcascade *hc, const struct nd_image *img);

#endif
