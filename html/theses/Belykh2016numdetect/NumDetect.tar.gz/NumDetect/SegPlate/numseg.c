#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <pthread.h>

#include <cairo.h>

#include "nd_image.h"

int main(int argc, char **argv)
{	
	struct nd_image img;
	struct nd_image hist;

	if (nd_imgread(&img, argv[1], 0)) {
		fprintf(stderr, "Cannot read image from file \"%s\".\n",
			argv[2]);

		exit(2);
	}

	int x;
	int y;
	int p;

	hist.w = img.w;
	hist.h = 100;
	hist.data = (double *) malloc(sizeof(double) * hist.w * hist.h);

	for (p = 0; p < hist.w * hist.h; ++p)
		hist.data[p] = 0.0;

	for (x = 0; x < img.w; ++x) {
		double sum;

		sum = 0.0;

		for (y = 0; y < img.h; ++y)
			sum += img.data[img.w * y + x];

		printf("%f\n", sum);

		for (y = 0; y < (int) ceil(sum); ++y)
			hist.data[hist.w * y + x] = 1.0;
	}

	nd_imgwrite(&hist, "hist.png");

	return 0;
}
