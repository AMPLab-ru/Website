# NumPlate 

*	HaarCascade -- API for working with Haar Cascade.
*	NormPlate -- tool, that removes perspective distorsions (normalizes) from number plate was found with haar cascade.
*	NeuroNet -- API for working with neuron net.
