# NeuroNet
Neuron net:
------

Teaching neuron net:

	./exlistmake.sh [examples directory] [iterations count]
	./nnetteach [examples list] [output file]

Reading symbol with neuron net:

	./readsym [neuron net data] [input image]
