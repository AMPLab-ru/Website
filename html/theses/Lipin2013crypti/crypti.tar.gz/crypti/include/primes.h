#ifndef PRIMES_H_
#define PRIMES_H_

unsigned int prime_nearest(unsigned int size);

#endif /*PRIMES_H_*/
