#ifndef __TYPE_CONVERTIONS_H_
#define __TYPE_CONVERTIONS_H_

void *convert_value(struct variable *dst_var, int to_type, struct variable *src_var, int from_type);

#endif
