#ifndef __CRYPTI_IO_H__
#define __CRYPTI_IO_H__

int cio_full_read(int fd, void *buf, size_t size);

#endif
