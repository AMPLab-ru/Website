#ifndef __CLIMITS_H__
#define __CLIMITS_H__


#define MAXFARGS 256
#define MAXRETARGS 256


#endif
