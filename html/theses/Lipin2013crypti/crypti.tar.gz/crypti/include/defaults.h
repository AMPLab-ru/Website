#ifndef __DEFAULTS_H__
#define __DEFAULTS_H__

#define INITIAL_SZ 32

int default_hash_compare(const void *a, const void *b);
unsigned long default_hash_cb(const void *data);

#endif
