#ifndef __RANDOM_H__
#define __RANDOM_H__

int rand_get_rand_bytes(unsigned char *dst, int nbytes);

#endif
