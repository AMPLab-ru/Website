#ifndef __KEY_H__
#define __KEY_H__

void keyword_table_init();

int keyword_table_lookup(char *name);

void keyword_table_destroy();

#endif

